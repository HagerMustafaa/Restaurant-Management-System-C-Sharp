﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurant_Management_System
{
    // Enum بنحدد فيه أنواع الأصناف اللي هتظهر في ComboBox


    public class Enums
    {
        public enum Category
        {
            Appetizer,
            MainCourse,
            Drinks,
            Desserts
        }
    }
   

}
